# Instructions for the SuperCollider version of the Fluid Corpus Manipulation toolbox

## How to start:

1) move the full FluidCorpusManipulation folder in your Extensions folder (see the 'Using Extensions' Guide in the documentation), and restart SuperCollider.

There is a Guide giving the overview of the toolbox. Full documentation is also available, as well as an Examples folder in the package.

#### Enjoy!

> This project has received funding from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement No 725899).
